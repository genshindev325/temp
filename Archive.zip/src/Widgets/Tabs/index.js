import Tabs from './Tabs';
import TabWrap from './TabWrap';

export { Tabs, TabWrap };
