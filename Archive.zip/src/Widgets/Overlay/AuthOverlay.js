import React from 'react';
import { useLocation, Redirect } from 'react-router-dom';
import { Content, Main } from 'Templates/Content';
import Header from 'App/View/Header/index';
import Footer from 'App/View/Footer/index';
import { auth } from 'Services';

const AuthOverlay = ({ children }) => {
    const { pathname } = useLocation();

    const exclude = ['/login', '/registration', '/forgot'];
    const isAuth = auth.isAuth();
    const isAuthPage = exclude.includes(pathname);

    if (!auth.isAuth() && !isAuthPage) {
        return <Redirect to="/login" />;
    }

    if (isAuthPage) {
        auth.logout();
    }

    return (
        <>
            <Content>
                <Header isAuth={!isAuth} />
                <Main>{children}</Main>
                {isAuth && <Footer />}
            </Content>
        </>
    );
};

export default AuthOverlay;
