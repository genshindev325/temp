import RequestService from './Request';

const request = new RequestService();

export { request };
