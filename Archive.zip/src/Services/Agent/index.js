import Auth from './Pages/Auth';

export { Auth };
