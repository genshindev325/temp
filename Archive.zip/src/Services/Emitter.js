import { EventEmitter } from 'events';

const emitter = new EventEmitter();

export { emitter };
