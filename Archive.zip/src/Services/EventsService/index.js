import { eventFrame } from './EventFrame';
import { handleScroll } from './EventScroll';

export { eventFrame, handleScroll };
