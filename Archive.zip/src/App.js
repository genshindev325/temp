import React from 'react';
import { BrowserRouter, Switch, Route } from 'react-router-dom';
import { AuthOverlay } from 'Widgets/Overlay';
import { PreloaderHoc } from 'Hoc';
import { ScrollToTop } from 'Templates/ScrollToTop';
import { Wrapper } from 'Templates/Content';
import Error from 'Pages/Error/Index/index';
import Login from 'Pages/Auth/Login/Index';
import Registration from 'Pages/Auth/Registration/Index';
import Forgot from 'Pages/Auth/Forgot/Index';
import Cabinet from 'Pages/Cabinet/Index/index';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const App = () => {
    return (
        <BrowserRouter>
            <ScrollToTop />
            <ToastContainer />
            <Wrapper>
                <AuthOverlay>
                    <Switch>
                        <Route exact path="/" component={Cabinet} />
                        <Route path="/login" component={Login} />
                        <Route path="/registration" component={Registration} />
                        <Route path="/forgot" component={Forgot} />
                        <Route path="*" component={Error} />
                    </Switch>
                </AuthOverlay>
            </Wrapper>
        </BrowserRouter>
    );
};

export default PreloaderHoc(App);
