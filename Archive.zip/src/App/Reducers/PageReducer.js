import LoginReducer from 'Pages/Auth/Login/Index/Reducers';
import RegistrationReducer from 'Pages/Auth/Registration/Index/Reducers';
import ForgotReducer from 'Pages/Auth/Forgot/Index/Reducers';
import CabinetReducer from 'Pages/Cabinet/Index/Reducers';

const reducers = [LoginReducer, RegistrationReducer, ForgotReducer, CabinetReducer];

const reducer = (state = {}, action) => {
    reducers.forEach((page) => page.forEach((reducer) => (state = reducer(state, action))));
    return state;
};

export default reducer;
