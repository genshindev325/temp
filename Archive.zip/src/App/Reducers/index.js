import { combineReducers } from "redux";
import AppReducer from "./AppReducer";
import PageReducer from "./PageReducer";
import {firebaseReducer} from 'react-redux-firebase'

export default combineReducers({
    appState: AppReducer,
    pageState: PageReducer,
    firebase: firebaseReducer
});
