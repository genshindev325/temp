const Constants = {
    PAGE_LOADING: 'PAGE_LOADING',
    PAGE_SUCCESSED: 'PAGE_SUCCESSED',
    PAGE_FAILED: 'PAGE_FAILED',
};

export default Constants;
