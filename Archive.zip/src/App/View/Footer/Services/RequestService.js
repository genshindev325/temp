// import request from 'Services/Request';

// export default async () => {
//     const { api } = await request;

//     api.directory.on("index", data => {
//         console.log("on INDEX", data);
//     })

//     return {
//         test: api.directory.index,
//     };
// };
