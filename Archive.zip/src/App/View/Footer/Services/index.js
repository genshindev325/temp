// import request from './RequestService';

const pref = 'footer';

export { pref };
