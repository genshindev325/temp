// import request from './RequestService';

const pref = 'header';

export { pref };
