import React from 'react';
import { compose } from 'redux';
import { NavLink, useHistory } from 'react-router-dom';
import { withTagDefaultProps } from 'Hoc';
import { Logo, TextLogo } from 'Templates/Logo';
import { Img } from 'Templates/Img';
import { auth } from 'Services';

const AuthHeader = ({ t }) => {
    const history = useHistory();
    const logout = () => {
        auth.logout();
        history.push('/login');
    };

    return (
        <>
            <div className="header__col">
                <Logo />
            </div>
            <div className="header__col">
                <TextLogo />
            </div>
            <div className="header__col">
                <NavLink to="/" className="header__link">
                    {t('Реферальная программа')}
                </NavLink>
                <button className="profile" type="button">
                    <span>ISA</span>
                </button>
                <button type="button" className="logout-btn" onClick={logout}>
                    <Img src="/assets/images/icons/logout.svg" alt="logout" />
                </button>
            </div>
        </>
    );
};

export default compose(withTagDefaultProps(null, null))(AuthHeader);
