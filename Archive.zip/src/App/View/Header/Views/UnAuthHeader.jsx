import React from 'react';
import { compose } from 'redux';
import { NavLink } from 'react-router-dom';
import { withTagDefaultProps } from 'Hoc';
import { Logo } from 'Templates/Logo';
import { Img } from 'Templates/Img';

const UnAuthHeader = ({ t }) => (
    <>
        <div className="header__col">
            <Logo />
        </div>
        <div className="header__col">
            <NavLink to="/" className="header__link header__link_simple">
                {t('Техническая поддержка')}
            </NavLink>
            <button className="add-user" type="button">
                <Img src="/assets/images/icons/add-user.svg" alt="add-user" />
            </button>
        </div>
    </>
);

export default compose(withTagDefaultProps(null, null))(UnAuthHeader);
