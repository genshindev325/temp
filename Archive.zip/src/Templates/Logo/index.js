import Logo from './Logo';
import TextLogo from './TextLogo';

export { Logo, TextLogo };
