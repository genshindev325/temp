import React from 'react';
import { compose } from 'redux';
import PropTypes from 'prop-types';
import { withTagDefaultProps } from 'Hoc';
import { NavLink } from 'react-router-dom';
import { withServiceConsumer } from 'Services/Context';
import { Button } from 'Templates/Button';
import { Img } from 'Templates/Img';

const propTypes = {
    total: PropTypes.string.isRequired,
    onClickReplenish: PropTypes.func.isRequired,
    onClickWithdraw: PropTypes.func.isRequired,
};

const BalanceCard = ({ total, onClickReplenish, onClickWithdraw, t }) => {
    return (
        <div className="balance-card" style={{ backgroundImage: 'url("/assets/images/content/balance-card-bg.svg")' }}>
            <div className="balance-card__title">{t('Баланс')}</div>
            <div className="balance-card__row">
                <div className="balance-card__col">
                    <span className="balance-card__total">{total}</span>
                    <span className="balance-card__icon">
                        <Img src="/assets/images/icons/balance-icon.svg" alt="balance-icon" />
                    </span>
                </div>
                <div className="balance-card__col">
                    <NavLink to="/" className="balance-card__link">
                        {t('История транзакций')}
                    </NavLink>
                </div>
            </div>
            <div className="balance-card__row">
                <div className="balance-card__col">
                    <Button name="replenish" onClick={onClickReplenish} fullWidth>
                        {t('Пополнить')}
                    </Button>
                </div>
                <div className="balance-card__col">
                    <Button name="withdraw" isBordered onClick={onClickWithdraw} fullWidth>
                        {t('Вывести')}
                    </Button>
                </div>
            </div>
        </div>
    );
};

BalanceCard.propTypes = propTypes;

export default compose(withServiceConsumer, withTagDefaultProps(null, null))(BalanceCard);
