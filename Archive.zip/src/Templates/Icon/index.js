import Icon from "./Icon";

export { Icon };
