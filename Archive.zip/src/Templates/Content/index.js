import Container from './Container';
import Wrapper from './Wrapper';
import Content from './Content';
import Main from './Main';
import Wrap from './Wrap';
import Separator from './Separator';

export { Container, Wrapper, Content, Main, Wrap, Separator };
