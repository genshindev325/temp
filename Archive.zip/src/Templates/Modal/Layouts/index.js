import ModalTemplate from './ModalTemplate';

export { ModalTemplate };
