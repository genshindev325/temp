import Modal from "./Modal";
import * as ModalDefault from "./Default";

export { Modal, ModalDefault };
