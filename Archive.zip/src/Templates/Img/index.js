import Img from "./Img";

export { Img };
