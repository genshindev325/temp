import ReferalCard from './ReferalCard';
import Referal from './Referal';

export { ReferalCard, Referal };
