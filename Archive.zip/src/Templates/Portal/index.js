import Portal from './Portal';
import SearchPortal from './SearchPortal';

export { Portal, SearchPortal };
