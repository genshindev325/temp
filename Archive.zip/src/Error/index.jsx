import ErrorBoundary from './Boundary';

export { ErrorBoundary };
