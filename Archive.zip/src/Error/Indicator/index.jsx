import React from 'react';

const ErrorIndicator = () => {
    return <div>ErrorIndicator</div>;
};

export default ErrorIndicator;
