import React from 'react';
import { compose } from 'redux';
import PropTypes from 'prop-types';
import { withTagDefaultProps } from 'Hoc';
import { withServiceConsumer } from 'Services/Context';
import { AuthSidebar } from 'Widgets/AuthSidebar';
import BlockForm from './BlockForm';
import BlockSuccess from './BlockSuccess';

const propTypes = {
    status: PropTypes.string.isRequired,
};

const MainWrap = ({ status, t }) => {
    return (
        <div className="auth">
            <AuthSidebar />
            <div className="auth__content">{status === 'success' ? <BlockSuccess /> : <BlockForm />}</div>
        </div>
    );
};

MainWrap.propTypes = propTypes;

const mapStateToProps = (state, ownProps) => {
    const { getStoreItem } = ownProps.service;

    return {
        status: getStoreItem(state, 'status', ''),
    };
};

export default compose(withServiceConsumer, withTagDefaultProps(mapStateToProps, null))(MainWrap);
