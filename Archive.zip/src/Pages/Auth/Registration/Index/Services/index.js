import getStoreItem, { getActionStore } from './StoreService';
import { requestRegister } from './RequestService';

const pref = 'auth';

export { getStoreItem, getActionStore, pref, requestRegister };
