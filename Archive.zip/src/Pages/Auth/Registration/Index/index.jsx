import React from 'react';
import { compose } from 'redux';
import { LoadPage, withTagDefaultProps } from 'Hoc';
import { ServiceProvider } from 'Services/Context';
import { Container } from 'Templates/Content';
import { MainWrap } from './Views';
import * as service from './Services';

const Registration = () => {
    return (
        <ServiceProvider value={service}>
            <Container>
                <MainWrap />
            </Container>
        </ServiceProvider>
    );
};

const mapDispatchToProps = (dispatch) => ({
    onLoad: service.getActionStore('pageLoad')(dispatch),
});

export default compose(withTagDefaultProps(null, mapDispatchToProps), LoadPage)(Registration);
