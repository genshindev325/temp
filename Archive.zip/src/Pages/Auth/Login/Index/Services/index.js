import getStoreItem, { getActionStore } from './StoreService';
import { requestSignIn } from './RequestService';

const pref = 'auth';

export { getStoreItem, getActionStore, pref, requestSignIn };
