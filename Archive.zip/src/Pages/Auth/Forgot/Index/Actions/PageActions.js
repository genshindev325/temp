import Constants from '../Constants';
import { requestForgot } from '../Services';

const fetchRequested = (dispatch) => {
    dispatch({ type: Constants.FETCH_ITEMS_REQUESTED });
};

export const pageLoad = (dispatch) => async () => {
    const data = {};

    dispatch({
        type: Constants.PAGE_LOADED,
        data,
    });
};

export const onChange = (dispatch) => (key, value) => {
    dispatch({ type: Constants.CHANGE_FORM, data: { key, value } });
};

export const submitForgotForm = (dispatch) => async (data) => {
    fetchRequested(dispatch);

    const res = await requestForgot(data);

    dispatch({
        type: Constants.FETCH_ITEMS_SUCCESSED,
        data: { status: 'success' },
    });
};
