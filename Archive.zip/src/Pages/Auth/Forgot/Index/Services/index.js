import getStoreItem, { getActionStore } from './StoreService';
import { requestForgot } from './RequestService';

const pref = 'auth';

export { getStoreItem, getActionStore, pref, requestForgot };
