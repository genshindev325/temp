import React from 'react';
import PropTypes from 'prop-types';
import { isEmpty } from 'ramda';
import { compose } from 'redux';
import { withTagDefaultProps } from 'Hoc';
import { withServiceConsumer } from 'Services/Context';
import { SliderWrap, Slider, SliderList, SliderItem } from 'Templates/Slider';
import { GameCard } from 'Templates/Game';

const propTypes = {
    games: PropTypes.arrayOf(PropTypes.any).isRequired,
};

const GamesSlider = ({ games, t }) => {
    return (
        <SliderWrap title={t('Мои игры')} subtitle={t('Вы участвовали в')} subject={`12 ${t('играх')}`}>
            {!isEmpty(games) && (
                <Slider controls>
                    <SliderList>
                        {games.map((item, index) => (
                            <SliderItem key={item.playId}>
                                <GameCard
                                    playNumber={item.playNumber}
                                    playId={item.playId}
                                    dateStart={item.dateStart}
                                    dateEnd={item.dateEnd}
                                    rate={item.rate}
                                    players={item.players}
                                    result={item.result}
                                />
                            </SliderItem>
                        ))}
                    </SliderList>
                </Slider>
            )}
        </SliderWrap>
    );
};

GamesSlider.propTypes = propTypes;

const mapStateToProps = (state, ownProps) => {
    const { getStoreItem } = ownProps.service;
    return {
        games: getStoreItem(state, 'games', []),
    };
};

export default compose(withServiceConsumer, withTagDefaultProps(mapStateToProps, null))(GamesSlider);
