import React from 'react';
import PropTypes from 'prop-types';
import { compose } from 'redux';
import { withTagDefaultProps } from 'Hoc';
import { withServiceConsumer } from 'Services/Context';
import { Img } from 'Templates/Img';
import { Progress, GameInfo } from 'Templates/Game';

const propTypes = {
    rate: PropTypes.string.isRequired,
    users: PropTypes.string.isRequired,
    id: PropTypes.string.isRequired,
    countToWithdraw: PropTypes.string.isRequired,
    items: PropTypes.arrayOf(PropTypes.any).isRequired,
    sum: PropTypes.string.isRequired,
    onChange: PropTypes.func.isRequired,
    submitForm: PropTypes.func.isRequired,
};

const GameBlock = ({ rate, users, id, countToWithdraw, items, sum, onChange, submitForm, t }) => {
    const submit = (e) => {
        e.preventDefault();
        submitForm({ sum });
    };
    return (
        <div className="game">
            <div className="game__head">
                <div className="game__col">
                    <div className="game__title">{t('Текущая X2 игра')}</div>
                </div>
                <div className="game__col">
                    <button type="button" className="game__head-btn">
                        {t('Вывести')}
                    </button>
                    <div className="game__head-info">
                        <span>{t('Сумма доступная для вывода:')}</span>
                        <span className="game__head-count">{countToWithdraw}</span>
                    </div>
                </div>
            </div>
            <div className="game__body">
                <GameInfo rate={rate} users={users} id={id} />
                <div className="game__row">
                    <div className="game__content" style={{ backgroundImage: 'url(/assets/images/icons/game-bg.svg)' }}>
                        <ul className="game__list">
                            {items.map(({ value, total, filled, type }, index) => {
                                return (
                                    <li key={`Progress-${index}`} className="game__item">
                                        <Progress
                                            number={index + 1}
                                            value={value}
                                            total={total}
                                            filled={filled}
                                            type={type}
                                        />
                                    </li>
                                );
                            })}
                        </ul>
                        <button className="game__collapse">
                            <Img src="/assets/images/icons/collapse.svg" alt="collapse" />
                            <span>{t('Посмотреть все очереди')}</span>
                        </button>
                    </div>
                    <div className="game__rate">
                        <form className="rate" onSubmit={submit}>
                            <button type="submit" className="rate__button">
                                <Img src="/assets/images/icons/rate.svg" alt="rate" />
                            </button>
                            <div className="rate__title">{t('Сделать ставку')}</div>
                            <input
                                className="rate__input"
                                type="number"
                                value={sum}
                                onChange={(e) => onChange('sum', e.target.value)}
                            />
                            <div className="rate__desc">{t('Введите сумму ставки')}</div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
};

GameBlock.propTypes = propTypes;

const mapStateToProps = (state, ownProps) => {
    const { getStoreItem } = ownProps.service;
    return {
        rate: getStoreItem(state, ['currentGame', 'rate'], ''),
        users: getStoreItem(state, ['currentGame', 'users'], ''),
        id: getStoreItem(state, ['currentGame', 'id'], ''),
        countToWithdraw: getStoreItem(state, ['currentGame', 'countToWithdraw'], ''),
        items: getStoreItem(state, ['currentGame', 'items'], []),
        sum: getStoreItem(state, ['form', 'sum'], ''),
    };
};

const mapDispatchToProps = (dispatch, { service: { getActionStore } }) => ({
    onChange: getActionStore('onChange')(dispatch),
    submitForm: getActionStore('submitForm')(dispatch),
});

export default compose(withServiceConsumer, withTagDefaultProps(mapStateToProps, mapDispatchToProps))(GameBlock);
