import React from 'react';
import PropTypes from 'prop-types';
import { compose } from 'redux';
import { withTagDefaultProps } from 'Hoc';
import { withServiceConsumer } from 'Services/Context';
import { BalanceCard, BalanceInfo } from 'Templates/Balance';

const propTypes = {
    total: PropTypes.string.isRequired,
    address: PropTypes.string.isRequired,
};

const BalanceBlock = ({ total, address }) => {
    return (
        <>
            <BalanceCard total={total} onClickReplenish={() => {}} onClickWithdraw={() => {}} />
            <BalanceInfo address={address} />
        </>
    );
};

BalanceBlock.propTypes = propTypes;

const mapStateToProps = (state, ownProps) => {
    const { getStoreItem } = ownProps.service;
    return {
        total: getStoreItem(state, ['balance', 'total'], ''),
        address: getStoreItem(state, ['balance', 'address'], ''),
    };
};

export default compose(withServiceConsumer, withTagDefaultProps(mapStateToProps, null))(BalanceBlock);
