import React from 'react';
import PropTypes from 'prop-types';
import { compose } from 'redux';
import { isEmpty } from 'ramda';
import { withTagDefaultProps } from 'Hoc';
import { withServiceConsumer } from 'Services/Context';
import { SliderWrap, Slider, SliderList, SliderItem } from 'Templates/Slider';
import { Referal } from 'Templates/Referal';

const propTypes = {
    referals: PropTypes.arrayOf(PropTypes.any).isRequired,
};

const ReferalSlider = ({ referals, t }) => {
    return (
        <SliderWrap title={t('Ваши рефералы')} subtitle={t('Вы пригласили')} subject={`8 ${t('участников')}`}>
            {!isEmpty(referals) && (
                <Slider controls>
                    <SliderList>
                        {referals.map((item, index) => (
                            <SliderItem key={index}>
                                <Referal name={item.name} bonus={item.bonus} date={item.date} />
                            </SliderItem>
                        ))}
                    </SliderList>
                </Slider>
            )}
        </SliderWrap>
    );
};

ReferalSlider.propTypes = propTypes;

const mapStateToProps = (state, ownProps) => {
    const { getStoreItem } = ownProps.service;
    return {
        referals: getStoreItem(state, 'referals', []),
    };
};

export default compose(withServiceConsumer, withTagDefaultProps(mapStateToProps, null))(ReferalSlider);
