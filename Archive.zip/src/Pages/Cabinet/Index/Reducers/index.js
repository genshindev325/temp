import { reducer as viewReducer } from "./ViewReducer";

export default [viewReducer];
