import getStoreItem, { getActionStore } from './StoreService';

const pref = 'error-page';

export { getStoreItem, getActionStore, pref };
