import withTagDefaultProps from './DefaultProps';
import LoadPage from './LoadPage';
import PreloaderHoc from './PreloaderHoc';

export { withTagDefaultProps, LoadPage, PreloaderHoc };
